﻿$(document).ready(function () {
    $('select').niceSelect();
    $('select').niceSelect('update');
});